CAPTAIN NANA DENNISON — PERSONAL WEBSITE

Files:
- index.html: website content and structure
- style.css: design and responsive layout
- script.js: mobile navigation and footer year

PUBLISH / UPDATE ON NETLIFY:
1. Keep all three files together in this folder.
2. Sign in to your Netlify account.
3. Open your site's Deploys page and use the manual deploy / upload option, or use Netlify Drop.
4. Upload this complete folder (or a ZIP containing the files at the site root).
5. Wait for the deploy to finish, then open your existing site URL.

The site uses Google Fonts and therefore needs an internet connection for those fonts to load. WhatsApp, Facebook and TikTok buttons open the public links supplied by the site owner.


VERSION 3 UPDATE
- Added the supplied professional portrait to the My Story/profile section.
- The portrait is included locally in assets/captain-nana-dennison-profile.png, so it loads with the site and does not depend on an external image link.
- Removed a repeated “Guiding Words” contact row.

To publish this update on the existing Netlify site, upload the contents of this folder (not just the ZIP file) to the site's Netlify deploy area. The live URL remains the same after a successful redeploy.
